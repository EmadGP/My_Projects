<?php

namespace App\Providers;

use Illuminate\Filesystem\Filesystem;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $files = File::files(app_path('helpers'));

        foreach ($files as $file) {
            require_once $file->getRealPath();
        }
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {

    }
}
